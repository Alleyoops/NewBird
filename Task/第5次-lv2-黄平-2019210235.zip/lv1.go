package main

import (
	"github.com/gin-gonic/gin"
	"net/http"
)
func main() {

	router := gin.Default()

	router.GET("/kiki", func(c *gin.Context) {
		c.JSON(200, gin.H{
			"code":    http.StatusOK,
			"message": "hello,guest!",
		})
	})

	router.GET("/home", AuthMiddleWare())

	router.GET("/auth/signin", func(c *gin.Context) {
		cookie := &http.Cookie{
			Name:     "ID",
			Value:    "123",
			Path:     "/",
			HttpOnly: true,
		}
		http.SetCookie(c.Writer, cookie)
		c.String(http.StatusOK, "login successfully!!")
	})
	router.Run()
}
func AuthMiddleWare() gin.HandlerFunc {
	return func(c *gin.Context) {
		if cookie, err := c.Request.Cookie("ID"); err == nil {
			value := cookie.Value
			if value == "123" {
				c.Next()
				c.JSON(200, gin.H{
					"code":    http.StatusOK,
					"message": "hello,kiki!",})
			}}else {c.JSON(http.StatusUnauthorized, gin.H{
				"error": "Unauthorized",
			})}
		c.Abort()

	}}