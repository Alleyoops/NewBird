//服务端
package main

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/gin-gonic/gin/binding"
	"log"
	"net/http"
)

type User struct {
	name string `form:"username" json:"username" binding:"required"`
	Age      int    `form:"age" json:"age"`
	StudentId int `form:"studentId" json:"studentId"`
	Gender string `form:"gender" json:"gender"`
	ClassId string `form:"classId" json:"classId"`
	Major string `form:"major" json:"major"`
	college string `form:"college" json:"college"`
}

func main() {
	router := gin.Default()
	router.POST("/localhost:8080/student?stuId=2019210235", func(c *gin.Context) {
		var user User
		user.name="XX"
		user.Age=19
		user.college="TXXY"
		user.Major="tx"
		user.ClassId="01141905"
		user.Gender="男"
		user.StudentId=2019210235
		var err error
		contentType := c.Request.Header.Get("Content-Type")
		switch contentType {
		case "application/json":
			err = c.BindJSON(&user)
		//兼容一些还是application/x-www-form-urlencoded的web表单页
		case "application/x-www-form-urlencoded":
			err = c.BindWith(&user, binding.Form)
		}
		if err != nil {
			fmt.Println(err)
			log.Fatal(err)
		}
		c.JSON(http.StatusOK, gin.H{
			"code":http.StatusOK,
			"message":"succes",
			"data":user,
		})
	})
	router.Run(":8080")
}