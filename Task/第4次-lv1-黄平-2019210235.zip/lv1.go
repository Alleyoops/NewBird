package main

import (
	"fmt"
	"time"
)

func main (){
	var t [5]int64
	fmt.Print("input:\n")
	for i:=0;i<5;i++{
		fmt.Scanf("%d",&t[i])
	}
	fmt.Println("input ok:")
	var str string
	for i:=0;i<5;i++{
		fmt.Scanf("%s",&str)
		if str=="ok" {
			fmt.Println(time.Unix(t[i],0))

		}else {
			fmt.Println(" error! input again:")
			i--
		}

	}
}