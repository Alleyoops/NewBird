package main

import "fmt"

func main(){

var a,b,c,sum,total int

fmt.Println("1、2、3、4个数字，能组成多少个互不相同且无重复数字的三位数有：")

for a=1; a<5; a++ {
	for b=1; b<5; b++ {
		for c=1; c<5; c++ {
			if a!=b && b!=c && a!=c {
				sum=100*a+10*b+1*c
				total++
				fmt.Println("",sum)
			}
		}
	}
}

fmt.Println("__________")
fmt.Printf("总计：%d种",total)
}
