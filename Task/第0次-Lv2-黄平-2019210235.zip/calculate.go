package main

import "fmt"

func main(){
	fmt.Println("25加25得：",25+25)
	fmt.Println("25.1乘25.2得：",25.1*25.2)
	fmt.Println("100除8得(8为被除数)：",8.0/100)

}