// Time : 2019/10/19 21:13
// remaker : Alleyoop

// effect
package effect

import "mashiroc.fun/dragongame/game"

// charge.go something

type Treat struct {
	game.BaseEffect
}

func (t Treat) Do(card game.Card, self, other game.Character) {
	card.Increase(2)
}