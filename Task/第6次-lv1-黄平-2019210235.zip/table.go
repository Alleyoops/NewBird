package main

import (
	"database/sql"
	"fmt"
	_ "github.com/go-sql-driver/mysql"
	"log"
)
var db *sql.DB//全局
func openconnect() (err error) {
	dsn := "root:123456@tcp(localhost)/stu?charset=utf8"
	db, err = sql.Open("mysql", dsn)
	if err != nil {
		return err
	}
	err = db.Ping()// 尝试与数据库建立连接（校验dsn是否正确）
	if err != nil {
		return err
	}
	return nil
}
//增
func insertDB(db *sql.DB)  {
	stmt, err := db.Prepare("insert into stutb(name,ID) values (?,?)")
	if err != nil{
		log.Fatal(err)
	}
	stmt.Exec("ph",222)
}
//改
func updateDB(db *sql.DB)  {
	stmt, err := db.Prepare("UPDATE stutb SET name = 'ppap' WHERE name='pp'")
	if err != nil{
		log.Fatal(err)
	}
	stmt.Exec();
}
//删
func deleteDB(db *sql.DB)  {
	stmt, err := db.Prepare("delete from stutb where name = 'hh'")
	if err != nil{
		log.Fatal(err);
	}
	stmt.Exec();
}
//查
func selectDB(db *sql.DB)  {
	stmt, err := db.Query("select * from stutb;")
	if err != nil {
		log.Fatal(err)
	}
	defer stmt.Close()
	for stmt.Next(){
		var ID int
		var name sql.NullString
		err := stmt.Scan(&ID,&name)
		if err != nil {
			log.Fatal(err)
		}
		fmt.Println(ID,name)
	}
}
func main(){
	openconnect()
	insertDB(db)
	updateDB(db)
	deleteDB(db)
	selectDB(db)
	db.Close()
}