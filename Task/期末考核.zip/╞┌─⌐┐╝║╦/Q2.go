package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
)

type stru struct {
	Code int `json:"code"`
	Info string `json:"info"`
	ReturnData struct{
		Xh string `json:"xh"`
		Xm string `json:"xm"`
		XmEn string `json:"xmEn"`
		Xb string `json:"xb"`
		Bj string `json:"bj"`
		Zyh string `json:"zyh"`
		Zym string `json:"zym"`
		Yxh string `json:"yxh"`
		Yxm string `json:"yxm"`
		Nj string `json:"nj"`
		Csrq string `json:"csrq"`
		Xjzt string `json:"xjzt"`
		Rxrq string `json:"rxrq"`
		Yxmen string `json:"yxmen"`
		ZymEn string `json:"zymEn"`
		Xz int `json:"xz"`
		Mz string `json:"mz"`
	}
}
func main() {
	JsonParse := NewJsonStruct()
	v := stru{}
	//下面使用的是相对路径，config.json文件和main.go文件处于同一目录下
	JsonParse.Load("./config.json", &v)
	fmt.Println(v.ReturnData.Xm)
}

type JsonStruct struct {
}

func NewJsonStruct() *JsonStruct {
	return &JsonStruct{}
}

func (jst *JsonStruct) Load(filename string, v interface{}) {
	//ReadFile函数会读取文件的全部内容，并将结果以[]byte类型返回
	data, err := ioutil.ReadFile(filename)
	if err != nil {
		return
	}
	//读取的数据为json格式，需要进行解码
	err = json.Unmarshal(data, &v)
	if err != nil {
		return
	}
}